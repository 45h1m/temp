from django.urls import path,re_path
from django.views.generic import TemplateView
from .views import RegisterView,LoginView,CreatePollView,VoteCreateView,MyPollsView,PollUpdateAPIView,home
urlpatterns = [
    re_path(r'^.*$', TemplateView.as_view(template_name="index.html")),
    path('api/register', RegisterView.as_view(), name='register'),
    path('api/login', LoginView.as_view(), name='login'),
    path('api/create', CreatePollView.as_view(), name='create_poll'),
    path('api/vote', VoteCreateView.as_view(), name='vote'),
    path('api/data', MyPollsView.as_view(), name='my-polls'),
    path('home/',home,name = "home"),
    path('api/update/<uuid:poll_id>/', PollUpdateAPIView.as_view(), name='poll-update'),
]

