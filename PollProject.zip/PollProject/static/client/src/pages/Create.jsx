import React from 'react'
import PollForm from '../components/PollForm'

const Create = () => {
  return (
    <div className='p-4'>
        <PollForm/>
    </div>
  )
}

export default Create