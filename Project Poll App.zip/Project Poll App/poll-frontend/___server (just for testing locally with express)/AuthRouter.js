const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const router = express.Router();

// In-memory users array (in production, you would use a database)
const users = [];

// Secret key for JWT (use environment variable in production)
const JWT_SECRET = 'your-secret-key';

/**
 * @route POST /api/register
 * @desc Register a new user
 * @access Public
 */
router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Validate inputs
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Please provide username, email and password'
      });
    }

    // Check if user already exists
    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: 'User with this email already exists'
      });
    }

    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create new user
    const newUser = {
      id: users.length + 1,
      username,
      email,
      password: hashedPassword
    };

    // Add to users array
    users.push(newUser);

    return res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: {
        id: newUser.id,
        username: newUser.username,
        email: newUser.email
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    return res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

/**
 * @route POST /api/login
 * @desc Login user and return JWT token
 * @access Public
 */
router.post('/login', async (req, res) => {
    try {
      const { email, password } = req.body;
  
      // Validate inputs
      if (!email || !password) {
        return res.status(400).json({
          success: false,
          error: 'Please provide email and password'
        });
      }
  
      // Find user
      const user = users.find(user => user.email === email);
      if (!user) {
        return res.status(400).json({
          success: false,
          error: 'Invalid credentials'
        });
      }
  
      // Validate password
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(400).json({
          success: false,
          error: 'Invalid credentials'
        });
      }
  
      // Create JWT token with username in payload
      const token = jwt.sign(
        { username: user.username, email: user.email },
        JWT_SECRET,
        { expiresIn: '1h' }
      );
  
      // Set token in HTTP-only cookie
      res.cookie('access_token', token, {
        httpOnly: false,
        secure: process.env.NODE_ENV === 'production', // Use secure in production
        maxAge: 3600000 // 1 hour in milliseconds, matching token expiry
      });
  
      return res.status(200).json({
        success: true,
        message: 'Logged in successfully',
        data: { token } // Still returning token in response if client needs it
      });
    } catch (error) {
      console.error('Login error:', error);
      return res.status(500).json({
        success: false,
        error: 'Server error'
      });
    }
  });

// Example of a protected route
router.get('/me', authenticateToken, (req, res) => {
  // The user's username is available in req.user.username from the middleware
  const user = users.find(user => user.username === req.user.username);
  
  if (!user) {
    return res.status(404).json({
      success: false,
      error: 'User not found'
    });
  }
  
  return res.status(200).json({
    success: true,
    data: {
      id: user.id,
      username: user.username,
      email: user.email
    }
  });
});

// Authentication middleware
function authenticateToken(req, res, next) {

    next(); // for development
  }

module.exports = {router, authenticateToken};