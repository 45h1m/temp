const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = process.env.PORT || 8000;
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const morgan = require('morgan')
const authRoutes = require('./AuthRouter'); 


// Middleware
app.use(bodyParser.json());
app.use(morgan('tiny'));
app.use(cors());

// Sample data with IDs added
let polls = [
  {
    id: "h347hd839bd73",
    question: "What's your favorite JS framework?",
    theme: "strawberry",
    options: [
      {"text": "React", "votes": 12},
      {"text": "Vue", "votes": 5},
      {"text": "Svelte", "votes": 3}
    ],
    createdBy: "605c5d8e8f1a4b0022bc1f9f",
    createdAt: "2025-04-10T12:00:00.000Z",
    updatedAt: "",
    accepting: true
  },
  {
    id: "dh3u4e32y6h2f42834d2",
    question: "Which cloud provider do you prefer?",
    theme: "blueberry",
    options: [
      {"text": "AWS", "votes": 24},
      {"text": "Azure", "votes": 18},
      {"text": "Google Cloud", "votes": 15},
      {"text": "DigitalOcean", "votes": 7}
    ],
    createdBy: "605c5d8e8f1a4b0022bc1f9f",
    createdAt: "2025-04-08T09:15:33.000Z",
    updatedAt: "2025-04-09T14:22:45.000Z",
    accepting: true
  },
  {
    id: "d3y2885yb85386639825",
    question: "Best programming language for beginners?",
    theme: "lime",
    options: [
      {"text": "Python", "votes": 42},
      {"text": "JavaScript", "votes": 28},
      {"text": "Java", "votes": 16},
      {"text": "C#", "votes": 11}
    ],
    createdBy: "60a72f4e9d8e3c0034b21caa",
    createdAt: "2025-04-05T18:30:00.000Z",
    updatedAt: "2025-04-09T22:15:10.000Z",
    accepting: true
  },
  {
    id: "dny58689682cb5238bt5c",
    question: "Favorite code editor?",
    theme: "grape",
    options: [
      {"text": "VS Code", "votes": 38},
      {"text": "JetBrains IDEs", "votes": 22},
      {"text": "Vim/Neovim", "votes": 15},
      {"text": "Sublime Text", "votes": 8},
      {"text": "Emacs", "votes": 6}
    ],
    createdBy: "61b3d45fc78aa20045def123",
    createdAt: "2025-04-02T10:45:22.000Z",
    updatedAt: "2025-04-08T16:33:40.000Z",
    accepting: true
  },
  {
    id: "dn3u4yr8765169b16158",
    question: "Most exciting tech trend for 2025?",
    theme: "tangerine",
    options: [
      {"text": "AI/ML advances", "votes": 34},
      {"text": "Web3/decentralized apps", "votes": 16},
      {"text": "AR/VR development", "votes": 23},
      {"text": "Edge computing", "votes": 12},
      {"text": "Quantum computing", "votes": 19}
    ],
    createdBy: "605c5d8e8f1a4b0022bc1f9f",
    createdAt: "2025-03-28T14:20:15.000Z",
    updatedAt: "2025-04-07T08:12:30.000Z",
    accepting: true
  }
];

app.use((req, res, next) => {
  res.setHeader("Content-Security-Policy", "default-src * 'self' data: 'unsafe-inline' 'unsafe-eval'; connect-src *");
  next();
});


// Routes

// Get all polls
app.get('/api/polls', authRoutes.authenticateToken ,async (req, res) => {

  await delay(2000)

  res.json({
    success: true,
    data: polls
  });
});

// Get poll by ID
app.get('/api/polls/:id', async(req, res) => {
  const poll = polls.find(p => p.id === req.params.id);
  
  if (!poll) {
    return res.status(404).json({
      success: false,
      message: 'Poll not found'
    });
  }

  await delay(2000)
  
  res.json({
    success: true,
    data: poll
  });
});

function delay(delay) {
  return new Promise(resolve => {
    setTimeout(resolve, delay);
  });
}

// Update poll (vote on an option)
app.post('/api/polls/vote/:id', async (req, res) => {
  const { id } = req.params;
  const { optionIndex } = req.body;
  
  const pollIndex = polls.findIndex(p => p.id === id);
  
  if (pollIndex === -1) {
    return res.status(404).json({
      success: false,
      message: 'Poll not found'
    });
  }
  
  const poll = polls[pollIndex];
  
  // Check if poll is still accepting votes
  if (!poll.accepting) {
    return res.status(400).json({
      success: false,
      message: 'This poll is no longer accepting votes'
    });
  }
  
  // Check if option index is valid
  if (optionIndex < 0 || optionIndex >= poll.options.length) {
    return res.status(400).json({
      success: false,
      message: 'Invalid option index'
    });
  }
  
  // Increment vote count
  poll.options[optionIndex].votes++;
  
  // Update the updatedAt timestamp
  poll.updatedAt = new Date().toISOString();
  
  // Update the polls array
  polls[pollIndex] = poll;
  
  await delay(2000)

  res.json({
    success: true,
    message: 'Vote recorded successfully',
    data: poll
  });
});

// Create a new poll
app.post('/api/polls', authRoutes.authenticateToken ,async (req, res) => {
  const { question, theme, options, createdBy } = req.body;
  
  // Input validation
  if (!question || !theme || !options || !Array.isArray(options) || options.length < 2 || !createdBy) {
    return res.status(400).json({
      success: false,
      message: 'Invalid poll data. Required: question, theme, at least 2 options, and createdBy.'
    });
  }
  
  // Create new poll with ID
  const newId = uuidv4();
  const newPoll = {
    id: newId,
    question,
    theme,
    options: options.map(opt => ({ text: opt.text, votes: 0 })),
    createdBy,
    createdAt: new Date().toISOString(),
    updatedAt: '',
    accepting: true
  };
  console.log(newPoll)
  polls.push(newPoll);
  
  await delay(2000);

  res.status(201).json({
    success: true,
    message: 'Poll created successfully',
    data: newPoll
  });
});

// Toggle poll accepting status
app.patch('/api/polls/:id/toggle-accepting', (req, res) => {
  const { id } = req.params;
  const pollIndex = polls.findIndex(p => p.id === id);
  
  if (pollIndex === -1) {
    return res.status(404).json({
      success: false,
      message: 'Poll not found'
    });
  }
  
  polls[pollIndex].accepting = !polls[pollIndex].accepting;
  polls[pollIndex].updatedAt = new Date().toISOString();
  
  res.json({
    success: true,
    message: `Poll is now ${polls[pollIndex].accepting ? 'accepting' : 'not accepting'} votes`,
    data: polls[pollIndex]
  });
});

// Delete a poll
app.delete('/api/polls/:id', (req, res) => {
  const { id } = req.params;
  const pollIndex = polls.findIndex(p => p.id === id);
  
  if (pollIndex === -1) {
    return res.status(404).json({
      success: false,
      message: 'Poll not found'
    });
  }
  
  const deletedPoll = polls.splice(pollIndex, 1)[0];
  
  res.json({
    success: true,
    message: 'Poll deleted successfully',
    data: deletedPoll
  });
});

// Update poll information (not just votes)
app.post('/api/update/:id',authRoutes.authenticateToken , async (req, res) => {
  const { id } = req.params;
  const { 
    optionIndex,           // For voting on a specific option
    question,              // Update poll question
    theme,                 // Update poll theme
    options,               // Replace options array
    accepting,             // Update accepting status
    addOption,             // Add a new option
    removeOptionIndex      // Remove an option by index
  } = req.body;

  console.log(req.body);
  
  const pollIndex = polls.findIndex(p => p.id === id);
  
  if (pollIndex === -1) {
    return res.status(404).json({
      success: false,
      message: 'Poll not found'
    });
  }
  
  const poll = { ...polls[pollIndex] };  // Create a copy to modify
  let modified = false;
  
  // Handle voting on an option
  if (optionIndex !== undefined) {
    // Check if poll is still accepting votes
    if (!poll.accepting) {
      return res.status(400).json({
        success: false,
        message: 'This poll is no longer accepting votes'
      });
    }
    
    // Check if option index is valid
    if (optionIndex < 0 || optionIndex >= poll.options.length) {
      return res.status(400).json({
        success: false,
        message: 'Invalid option index'
      });
    }
    
    // Increment vote count
    poll.options[optionIndex].votes++;
    modified = true;
  }
  
  // Update question
  if (question !== undefined) {
    poll.question = question;
    modified = true;
  }
  
  // Update theme
  if (theme !== undefined) {
    poll.theme = theme;
    modified = true;
  }
  
  // Update accepting status
  if (accepting !== undefined) {
    poll.accepting = Boolean(accepting);
    modified = true;
  }
  
  // Replace entire options array
  if (options !== undefined && Array.isArray(options)) {
    // Validate the new options array
    if (options.length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Poll must have at least 2 options'
      });
    }
    
    // Convert options to proper format if they aren't already
    poll.options = options.map(opt => {
      if (typeof opt === 'string') {
        return { text: opt, votes: 0 };
      } else if (typeof opt === 'object' && opt.text) {
        return { 
          text: opt.text, 
          votes: opt.votes !== undefined ? opt.votes : 0 
        };
      }
      return opt;
    });
    modified = true;
  }
  
  // Add a new option
  if (addOption !== undefined) {
    const newOption = typeof addOption === 'string' 
      ? { text: addOption, votes: 0 }
      : { text: addOption.text, votes: addOption.votes || 0 };
    
    poll.options.push(newOption);
    modified = true;
  }
  
  // Remove an option
  if (removeOptionIndex !== undefined) {
    // Check if option index is valid
    if (removeOptionIndex < 0 || removeOptionIndex >= poll.options.length) {
      return res.status(400).json({
        success: false,
        message: 'Invalid option index for removal'
      });
    }
    
    // Ensure we always have at least 2 options
    if (poll.options.length <= 2) {
      return res.status(400).json({
        success: false,
        message: 'Cannot remove option: poll must have at least 2 options'
      });
    }
    
    poll.options.splice(removeOptionIndex, 1);
    modified = true;
  }
  
  // Only update timestamp if something was modified
  if (modified) {
    poll.updatedAt = new Date().toISOString();
    polls[pollIndex] = poll;
  } else {
    return res.status(400).json({
      success: false,
      message: 'No valid update parameters provided'
    });
  }

  await delay(2000);
  
  res.json({
    success: true,
    message: 'Poll updated successfully',
    data: poll
  });
});

app.use('/api', authRoutes.router);

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

// Export for testing purposes
module.exports = app;